from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A5, A4, landscape
from build import simbolo, spaced, MM, GRAFITE, LINHA

W5, H5 = A5
TXT = GRAFITE


def linha(c, x0, x1, y):
    c.setStrokeColor(LINHA); c.setLineWidth(0.5); c.line(x0, y, x1, y)


def atestado(c, ox=0, oy=0):
    c.saveState(); c.translate(ox, oy)
    W, H = W5, H5
    X0, X1 = 14 * MM, W - 14 * MM

    # Marca d'água
    simbolo(c, W / 2, H / 2 - 6 * MM, 92 * MM, alpha=0.07)

    # Cabeçalho
    simbolo(c, W / 2, H - 17 * MM, 12 * MM)
    c.setFillColor(TXT); c.setFont("Corm", 15.5)
    c.drawCentredString(W / 2, H - 29 * MM, "Dra. Andressa Namba")
    spaced(c, "CIRURGIÃ-DENTISTA  ·  CRO-SP 158296", W / 2, H - 33.5 * MM, "MonL", 5.6, 1.3)
    linha(c, W / 2 - 22 * MM, W / 2 + 22 * MM, H - 37 * MM)

    # Título
    c.setFillColor(TXT); c.setFont("Corm", 17)
    c.drawCentredString(W / 2, H - 48 * MM, "Atestado")

    # Corpo
    fs, ld = 8.4, 10.6 * MM
    c.setFont("MonL", fs)

    def txt(s, x, y):
        c.setFillColor(TXT); c.setFont("MonL", fs); c.drawString(x, y, s)
        return x + c.stringWidth(s, "MonL", fs)

    y = H - 60 * MM
    txt("Atesto, para os devidos fins, que o(a) Sr.(a)", X0, y)
    y -= ld; linha(c, X0, X1, y - 1.5)
    y -= ld; x = txt("portador(a) do documento", X0, y); linha(c, x + 2, X1, y - 1.5)
    y -= ld; txt("esteve sob meus cuidados profissionais no período", X0, y)
    y -= ld
    x = txt("das", X0, y); linha(c, x + 2, x + 16 * MM, y - 1.5); x += 17.5 * MM
    x = txt("às", x, y); linha(c, x + 2, x + 16 * MM, y - 1.5); x += 17.5 * MM
    x = txt("do dia", x, y)
    xd = x + 2
    linha(c, xd, X1 - 0.5 * MM, y - 1.5)
    c.setFillColor(LINHA); c.setFont("MonL", fs)
    seg = (X1 - xd) / 3
    c.drawCentredString(xd + seg, y, "/"); c.drawCentredString(xd + 2 * seg, y, "/")
    y -= ld
    x = txt("necessitando o(a) mesmo(a) de", X0, y); linha(c, x + 2, x + 14 * MM, y - 1.5)
    txt("dia(s) de convalescença.", x + 15.5 * MM, y)
    y -= ld
    x = txt("CID", X0, y); linha(c, x + 2, x + 24 * MM, y - 1.5)
    c.setFillColor(TXT); c.setFont("MonL", 5.8)
    c.drawString(x + 26 * MM, y, "(somente com autorização do paciente)")

    # Local e data
    y -= 1.6 * ld
    x = txt("São José dos Campos,", X0, y)
    linha(c, x + 2, x + 9 * MM, y - 1.5); x += 10.5 * MM
    x = txt("de", x, y); linha(c, x + 2, x + 26 * MM, y - 1.5); x += 27.5 * MM
    x = txt("de 20", x, y); linha(c, x + 1, x + 7 * MM, y - 1.5)

    # Assinatura
    yb = 34 * MM
    linha(c, W / 2 - 30 * MM, W / 2 + 30 * MM, yb)
    c.setFillColor(TXT); c.setFont("Corm", 10.5)
    c.drawCentredString(W / 2, yb - 4.8 * MM, "Dra. Andressa Namba")
    c.setFont("MonL", 5.4)
    c.drawCentredString(W / 2, yb - 8.2 * MM, "ASSINATURA E CARIMBO")

    # Rodapé
    linha(c, X0, X1, 16 * MM)
    spaced(c, "R. EUCLIDES MIRAGAIA, 464  ·  SALA 15  ·  CENTRO  ·  SÃO JOSÉ DOS CAMPOS – SP", W / 2, 11.5 * MM, "MonL", 5.1, 0.7)
    spaced(c, "(12) 99784-2434", W / 2, 8 * MM, "MonL", 5.1, 0.7)
    c.restoreState()


def a5(path):
    c = canvas.Canvas(path, pagesize=A5)
    c.setTitle("Atestado A5 – Dra. Andressa Namba")
    atestado(c); c.showPage(); c.save()


def a4_2up(path):
    WL, HL = landscape(A4)
    c = canvas.Canvas(path, pagesize=landscape(A4))
    c.setTitle("Atestado – 2 por folha A4 – Dra. Andressa Namba")
    atestado(c, 0, 0); atestado(c, W5, 0)
    # linha de corte
    c.setStrokeColor(LINHA); c.setLineWidth(0.4); c.setDash(2, 3)
    c.line(W5, 0, W5, 6 * MM); c.line(W5, HL - 6 * MM, W5, HL)
    c.showPage(); c.save()


if __name__ == "__main__":
    a5("/home/claude/receituario/Atestado-A5.pdf")
    a4_2up("/home/claude/receituario/Atestado-2-por-folha-A4.pdf")
    print("ok")
