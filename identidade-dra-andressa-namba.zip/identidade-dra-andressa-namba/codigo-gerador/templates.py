from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, Frame, Spacer, Table, TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT
from build import pagina, W, H, MM, GRAFITE, LINHA, A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
pdfmetrics.registerFont(TTFont('DejaVu', '/usr/share/fonts/truetype/dejavu/DejaVuSans-ExtraLight.ttf'))

TXT = GRAFITE
EMAIL = "andressanamba@outlook.com"

titulo = ParagraphStyle("t", fontName="Corm", fontSize=19, leading=23, alignment=TA_CENTER, textColor=TXT)
corpo = ParagraphStyle("c", fontName="MonL", fontSize=9.6, leading=16, alignment=TA_JUSTIFY, textColor=TXT)
rot = ParagraphStyle("r", parent=corpo, alignment=TA_LEFT)
item = ParagraphStyle("i", parent=corpo, alignment=TA_LEFT, leading=14)
obs = ParagraphStyle("o", parent=corpo, fontSize=8.8, leading=14)

X0, X1 = 22 * MM, W - 22 * MM
TOPO = H - 62 * MM


def frame(c, flow, top=TOPO, bottom=70 * MM):
    f = Frame(X0, bottom, X1 - X0, top - bottom, leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0, showBoundary=0)
    f.addFromList(flow, c)


def linha(c, x0, x1, y):
    c.setStrokeColor(LINHA); c.setLineWidth(0.5); c.line(x0, y, x1, y)


def campo_paciente(c, y):
    c.setFillColor(TXT); c.setFont("MonL", 9.2)
    c.drawString(X0, y, "Paciente")
    linha(c, X0 + 16 * MM, X1, y - 1.5)


def local_data_assinatura(c, y=52 * MM):
    c.setFillColor(TXT); c.setFont("MonL", 9.2)
    c.drawString(X0, y, "São José dos Campos,")
    linha(c, X0 + 37 * MM, X0 + 46 * MM, y - 1.5)
    c.drawString(X0 + 47.5 * MM, y, "de")
    linha(c, X0 + 53 * MM, X0 + 80 * MM, y - 1.5)
    c.drawString(X0 + 81.5 * MM, y, "de 20")
    linha(c, X0 + 92 * MM, X0 + 99 * MM, y - 1.5)
    yb = y - 15 * MM
    cx = W / 2
    linha(c, cx - 35 * MM, cx + 35 * MM, yb)
    c.setFont("Corm", 11.5); c.drawCentredString(cx, yb - 5.5 * MM, "Dra. Andressa Namba")
    c.setFont("MonL", 6.8); c.drawCentredString(cx, yb - 9.5 * MM, "CIRURGIÃ-DENTISTA  ·  CRO-SP 158296")


from reportlab.platypus.flowables import Flowable


class Caixa(Flowable):
    def __init__(self, s=3.2 * MM):
        super().__init__(); self.s = s
    def wrap(self, aw, ah):
        return self.s, self.s + 2
    def draw(self):
        self.canv.setStrokeColor(GRAFITE); self.canv.setLineWidth(0.6)
        self.canv.rect(0, 0, self.s, self.s, stroke=1, fill=0)


def checklist(itens):
    rows = [[Caixa(), Paragraph(t, item)] for t in itens]
    t = Table(rows, colWidths=[7 * MM, X1 - X0 - 7 * MM])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0),
                           ("TOPPADDING", (0, 0), (-1, -1), 1.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 1.5)]))
    return t


# ---------- Modelo 1: Escaneamento intraoral ----------
def modelo1(path):
    c = canvas.Canvas(path, pagesize=A4)
    c.setTitle("Pedido de Escaneamento Intraoral – Dra. Andressa Namba")
    pagina(c, campos=False)
    frame(c, [Paragraph("Pedido de Escaneamento Intraoral", titulo)], top=TOPO, bottom=TOPO - 12 * MM)
    campo_paciente(c, TOPO - 24 * MM)
    frame(c, [
        Paragraph("Solicito, por gentileza, a realização de escaneamento intraoral das arcadas superior e "
                  "inferior, com registro de mordida em MIH.", corpo),
        Spacer(1, 7 * MM),
        Paragraph(f"Favor enviar os arquivos em formato <font name='Mon'>.STL</font> para o e-mail "
                  f"<font name='Mon'>{EMAIL}</font>.", corpo),
        Spacer(1, 10 * MM),
        Paragraph("Observações", rot),
    ], top=TOPO - 38 * MM)
    for k in range(3):
        linha(c, X0, X1, TOPO - 85 * MM - k * 9 * MM)
    local_data_assinatura(c)
    c.showPage(); c.save()


# ---------- Modelo 2: Documentação ortodôntica + escaneamento ----------
ORIENT = [
    "O escaneamento só deve ser realizado após a finalização do tratamento clínico (restaurações, próteses, raspagem etc.).",
    "Todos os dentes presentes na arcada devem ser copiados.",
    "Quanto maior a superfície de gengiva escaneada, melhor, com no mínimo 3 mm escaneados.",
    "Não deve haver bolhas positivas ou negativas de saliva.",
    "Na presença de terceiros molares de difícil acesso, é necessário escanear pelo menos metade do dente.",
    "Áreas edêntulas podem ficar distorcidas, pois o scanner pode ter dificuldade com as referências e encurtar ou "
    "alongar a região. Compare sempre a imagem do scan com a área no paciente e, se necessário, reescaneie.",
    "Para contenções, o escaneamento só é necessário se houver intervenção clínica que altere a anatomia dentária.",
    "Em escaneamentos para refinamento, a remoção dos attachments fica a critério do dentista.",
]


def modelo2(path):
    c = canvas.Canvas(path, pagesize=A4)
    c.setTitle("Pedido de Documentação Ortodôntica com Escaneamento – Dra. Andressa Namba")
    # Página 1
    pagina(c, campos=False)
    frame(c, [Paragraph("Pedido de Documentação Ortodôntica<br/>com Escaneamento", titulo)], top=TOPO, bottom=TOPO - 18 * MM)
    c.setFillColor(TXT); c.setFont("MonL", 9.4)
    c.drawString(X0, TOPO - 27 * MM, "Ao centro radiológico,")
    campo_paciente(c, TOPO - 37 * MM)
    frame(c, [
        Paragraph("Solicito, para o(a) paciente acima, documentação ortodôntica completa contendo:", corpo),
        Spacer(1, 3 * MM),
        checklist(["5 fotos intraorais", "3 fotos extraorais", "Radiografia panorâmica",
                   "Telerradiografia com traçados cefalométricos",
                   "Escaneamento intraoral das arcadas superior e inferior",
                   "Outros: ____________________________________________________________"]),
        Spacer(1, 5 * MM),
        Paragraph("O escaneamento intraoral das duas arcadas deve ser realizado com registro de mordida em MIH e "
                  "paciente sentado. Solicito o envio dos arquivos da arcada superior, da arcada inferior e do "
                  f"registro de mordida em formato <font name='Mon'>.STL</font> para "
                  f"<font name='Mon'>{EMAIL}</font>.", corpo),
        Spacer(1, 5 * MM),
        Paragraph("<font name='Mon'>OBS.:</font> confirmar com o paciente a finalização de todo o tratamento "
                  "clínico antes do escaneamento.", obs),
    ], top=TOPO - 46 * MM, bottom=68 * MM)
    local_data_assinatura(c)
    c.showPage()

    # Página 2 – orientações
    pagina(c, campos=False)
    bul = ParagraphStyle("b", parent=corpo, leading=14.5, leftIndent=5 * MM, bulletIndent=0, spaceAfter=3.2 * MM)
    flow = [Paragraph("Orientações para Escaneamento", titulo), Spacer(1, 7 * MM),
            Paragraph("O escaneamento é um exame de suma importância para o tratamento com alinhadores. "
                      "Por isso, é essencial atenção aos seguintes detalhes:", corpo), Spacer(1, 5 * MM)]
    flow += [Paragraph(t, bul, bulletText="·") for t in ORIENT]
    flow += [Spacer(1, 3 * MM),
             Paragraph("Caso ocorra algum desses problemas, a Sousmile solicitará novo escaneamento para garantir "
                       "a qualidade e o resultado do tratamento.", corpo),
             Spacer(1, 7 * MM),
             Paragraph("<font name='CormIt' size='13'>Ficamos à disposição para qualquer dúvida.</font>",
                       ParagraphStyle("f", parent=corpo, alignment=TA_CENTER))]
    frame(c, flow, top=TOPO, bottom=30 * MM)
    c.showPage(); c.save()


if __name__ == "__main__":
    modelo1("/home/claude/receituario/Pedido-Escaneamento-Intraoral.pdf")
    modelo2("/home/claude/receituario/Pedido-Documentacao-Ortodontica-Escaneamento.pdf")
    print("ok")
