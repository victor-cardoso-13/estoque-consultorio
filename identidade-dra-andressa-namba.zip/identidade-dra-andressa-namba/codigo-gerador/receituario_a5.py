from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A5, A4, landscape
from build import simbolo, spaced, MM, GRAFITE, LINHA

W5, H5 = A5
TXT = GRAFITE


def linha(c, x0, x1, y):
    c.setStrokeColor(LINHA); c.setLineWidth(0.5); c.line(x0, y, x1, y)


def receituario(c, ox=0, oy=0):
    c.saveState(); c.translate(ox, oy)
    W, H = W5, H5
    X0, X1 = 14 * MM, W - 14 * MM

    # Marca d'água
    simbolo(c, W / 2, H / 2 - 4 * MM, 92 * MM, alpha=0.07)

    # Cabeçalho
    simbolo(c, W / 2, H - 17 * MM, 12 * MM)
    c.setFillColor(TXT); c.setFont("Corm", 15.5)
    c.drawCentredString(W / 2, H - 29 * MM, "Dra. Andressa Namba")
    spaced(c, "CIRURGIÃ-DENTISTA  ·  CRO-SP 158296", W / 2, H - 33.5 * MM, "MonL", 5.6, 1.3)
    linha(c, W / 2 - 22 * MM, W / 2 + 22 * MM, H - 37 * MM)

    # Paciente
    fs = 8.4
    y = H - 48 * MM
    c.setFillColor(TXT); c.setFont("MonL", fs)
    c.drawString(X0, y, "Paciente")
    linha(c, X0 + c.stringWidth("Paciente", "MonL", fs) + 2.5 * MM, X1, y - 1.5)

    # Data e assinatura
    yd = 40 * MM
    c.setFillColor(TXT); c.setFont("MonL", fs)
    c.drawString(X0, yd, "Data")
    xd = X0 + c.stringWidth("Data", "MonL", fs) + 2.5 * MM
    linha(c, xd, xd + 30 * MM, yd - 1.5)
    c.setFillColor(LINHA)
    c.drawCentredString(xd + 10 * MM, yd, "/"); c.drawCentredString(xd + 20 * MM, yd, "/")

    xs0, xs1 = W - 14 * MM - 52 * MM, W - 14 * MM
    linha(c, xs0, xs1, yd - 1.5)
    cx = (xs0 + xs1) / 2
    c.setFillColor(TXT); c.setFont("Corm", 10)
    c.drawCentredString(cx, yd - 6 * MM, "Dra. Andressa Namba")
    c.setFont("MonL", 5.2)
    c.drawCentredString(cx, yd - 9.2 * MM, "ASSINATURA E CARIMBO")

    # Rodapé
    linha(c, X0, X1, 16 * MM)
    spaced(c, "R. EUCLIDES MIRAGAIA, 464  ·  SALA 15  ·  CENTRO  ·  SÃO JOSÉ DOS CAMPOS – SP", W / 2, 11.5 * MM, "MonL", 5.1, 0.7)
    spaced(c, "(12) 99784-2434", W / 2, 8 * MM, "MonL", 5.1, 0.7)
    c.restoreState()


def a5(path):
    c = canvas.Canvas(path, pagesize=A5)
    c.setTitle("Receituário A5 – Dra. Andressa Namba")
    receituario(c); c.showPage(); c.save()


def a4_2up(path):
    WL, HL = landscape(A4)
    c = canvas.Canvas(path, pagesize=landscape(A4))
    c.setTitle("Receituário – 2 por folha A4 – Dra. Andressa Namba")
    receituario(c, 0, 0); receituario(c, W5, 0)
    c.setStrokeColor(LINHA); c.setLineWidth(0.4); c.setDash(2, 3)
    c.line(W5, 0, W5, 6 * MM); c.line(W5, HL - 6 * MM, W5, HL)
    c.showPage(); c.save()


if __name__ == "__main__":
    a5("/home/claude/receituario/Receituario-A5.pdf")
    a4_2up("/home/claude/receituario/Receituario-A5-2-por-folha-A4.pdf")
    print("ok")
