import re, sys
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor

F = "/home/claude/fonts/"
pdfmetrics.registerFont(TTFont("Corm", F + "Cormorant-Medium.ttf"))
pdfmetrics.registerFont(TTFont("CormIt", F + "Cormorant-Italic.ttf"))
pdfmetrics.registerFont(TTFont("MonL", F + "Montserrat-Light.ttf"))
pdfmetrics.registerFont(TTFont("Mon", F + "Montserrat-Regular.ttf"))

GRAFITE = HexColor("#5F5F62")
LINHA = HexColor("#BDBDC0")
W, H = A4
MM = 72 / 25.4

svg = open("/home/claude/receituario/simbolo-AN.svg").read()
vb = [float(x) for x in re.search(r'viewBox="([^"]+)"', svg).group(1).split()]
D = re.search(r' d="([^"]+)"', svg).group(1)
TOK = re.findall(r"[MLCZ]|-?\d+\.?\d*", D)


def simbolo(c, cx, cy, size, alpha=1.0, color=GRAFITE):
    """Desenha o símbolo vetorial centrado em (cx, cy) com largura `size`."""
    x0, y0, vw, vh = vb
    s = size / vw
    hgt = vh * s
    c.saveState()
    c.setFillColor(color)
    c.setFillAlpha(alpha)
    c.translate(cx - size / 2, cy + hgt / 2)
    c.scale(s, -s)
    c.translate(-x0, -y0)
    p = c.beginPath()
    i = 0
    while i < len(TOK):
        t = TOK[i]
        if t == "M":
            p.moveTo(float(TOK[i + 1]), float(TOK[i + 2])); i += 3
        elif t == "L":
            p.lineTo(float(TOK[i + 1]), float(TOK[i + 2])); i += 3
        elif t == "C":
            v = [float(x) for x in TOK[i + 1:i + 7]]
            p.curveTo(*v); i += 7
        elif t == "Z":
            p.close(); i += 1
        else:
            i += 1
    c.drawPath(p, fill=1, stroke=0, fillMode=1)  # even-odd
    c.restoreState()


def spaced(c, text, x, y, font, size, tracking, center=True):
    c.saveState()
    c.setFont(font, size)
    w = sum(pdfmetrics.stringWidth(ch, font, size) for ch in text) + tracking * (len(text) - 1)
    if center:
        x = x - w / 2
    t = c.beginText(x, y)
    t.setFont(font, size)
    t.setCharSpace(tracking)
    t.textOut(text)
    t.setCharSpace(0)
    c.drawText(t)
    c.restoreState()


def pagina(c, campos=True):
    # Marca d'água
    simbolo(c, W / 2, H / 2 - 10, 120 * MM, alpha=0.07)

    # Cabeçalho
    simbolo(c, W / 2, H - 27 * MM, 17 * MM)
    c.setFillColor(GRAFITE)
    c.setFont("Corm", 21)
    c.drawCentredString(W / 2, H - 44 * MM, "Dra. Andressa Namba")
    spaced(c, "CIRURGIÃ-DENTISTA  ·  CRO-SP 158296", W / 2, H - 50 * MM, "MonL", 7.2, 1.6)
    c.setStrokeColor(LINHA)
    c.setLineWidth(0.5)
    c.line(W / 2 - 30 * MM, H - 55 * MM, W / 2 + 30 * MM, H - 55 * MM)

    if campos:
        c.setFillColor(GRAFITE)
        c.setFont("MonL", 8.5)
        y = H - 68 * MM
        c.drawString(20 * MM, y, "Paciente")
        c.setStrokeColor(LINHA)
        c.line(36 * MM, y - 1.5, W - 20 * MM, y - 1.5)

        # Data e assinatura
        yb = 52 * MM
        c.drawString(20 * MM, yb, "Data")
        c.line(29 * MM, yb - 1.5, 80 * MM, yb - 1.5)
        c.line(W - 85 * MM, yb - 1.5, W - 20 * MM, yb - 1.5)
        cx = W - 52.5 * MM
        c.setFont("Corm", 11)
        c.drawCentredString(cx, yb - 6 * MM, "Dra. Andressa Namba")
        c.setFont("MonL", 6.5)
        c.drawCentredString(cx, yb - 10 * MM, "CRO-SP 158296")

    # Rodapé
    c.setStrokeColor(LINHA)
    c.setLineWidth(0.5)
    c.line(20 * MM, 24 * MM, W - 20 * MM, 24 * MM)
    c.setFillColor(GRAFITE)
    spaced(c, "R. EUCLIDES MIRAGAIA, 464  ·  SALA 15  ·  CENTRO", W / 2, 18 * MM, "MonL", 6.8, 1.2)
    spaced(c, "SÃO JOSÉ DOS CAMPOS – SP  ·  12245-820", W / 2, 13.5 * MM, "MonL", 6.8, 1.2)


def build(path, campos):
    c = canvas.Canvas(path, pagesize=A4)
    c.setTitle("Receituário – Dra. Andressa Namba")
    c.setAuthor("Dra. Andressa Namba")
    pagina(c, campos)
    c.showPage()
    c.save()


if __name__ == "__main__":
  build("/home/claude/receituario/Receituario-Andressa-Namba.pdf", True)
  build("/home/claude/receituario/fundo-sem-campos.pdf", False)
  print("ok")
