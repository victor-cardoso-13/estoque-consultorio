# Identidade visual — Dra. Andressa Namba (Odontologia)

Pacote de referência para o app do consultório. Tudo aqui já foi aprovado na papelaria impressa. O app deve seguir a mesma linguagem: minimalista, elegante, muito espaço em branco, cinza grafite, sem gradientes e sem sombras pesadas.

## Dados do consultório

| Campo | Valor |
|---|---|
| Nome de exibição | Dra. Andressa Namba |
| Nome completo | Andressa Mayumi Namba |
| Profissão | Cirurgiã-Dentista |
| CRO | CRO-SP 158296 |
| Endereço | R. Euclides Miragaia, 464 · Sala 15 · Centro · São José dos Campos – SP · 12245-820 |
| Telefone / WhatsApp | (12) 99784-2434 |
| E-mail | **pendente de definição**: os pedidos de escaneamento usam `andressanamba@outlook.com` e o atestado antigo usava `andressa.namba@unesp.br` |

## Marca

- Símbolo: monograma **"AN"** com serifa fina, dentro de um círculo aberto em pincelada (ensō).
- `marca/simbolo-AN.svg`: vetor principal, cor grafite `#6E6E70`. Use sempre o SVG; o PNG é só um fallback.
- `marca/simbolo-AN-branco.svg`: para fundos escuros.
- `marca/simbolo-AN-marca-dagua.svg`: versão pré-clareada (`#EFEFF0`) para fundos de tela e documentos.
- `marca/icone-*.png`: ícones do app/PWA (512, 192, 180 apple-touch e 32 favicon), símbolo centralizado em fundo branco.
- Regras: não distorcer, não recolorir fora da paleta, não aplicar efeitos. Manter respiro de pelo menos 25% da largura do símbolo ao redor. Na papelaria, a marca d'água fica centralizada com ~7% de opacidade.

## Cores

```css
:root {
  --grafite: #5F5F62;        /* textos, títulos, nome */
  --grafite-simbolo: #6E6E70;/* símbolo */
  --linha: #BDBDC0;          /* divisores, bordas, linhas de campo */
  --nevoa: #EFEFF0;          /* fundos suaves, marca d'água, hover */
  --papel: #FFFFFF;          /* fundo principal */
  --tinta: #3F3F42;          /* sugestão p/ texto de corpo longo em tela (contraste AA) */
}
```

A identidade é monocromática. Se o app precisar de uma cor de ação (botão primário, alertas), use uma só, discreta, e trate-a como acréscimo do app, não da marca. Para estados de sucesso e erro, use tons dessaturados.

## Tipografia

Ambas são Google Fonts (licença OFL, uso livre). Os arquivos variáveis estão em `fontes/`.

| Uso | Fonte | Peso | Observação |
|---|---|---|---|
| Nome da doutora, títulos de documento/tela | Cormorant Garamond | 500 (Medium) | tamanhos grandes; nunca em caixa alta |
| Frases de destaque | Cormorant Garamond Italic | 400 | uso pontual |
| Corpo, campos, rótulos | Montserrat | 300 (Light) | 400 para textos pequenos em tela, por legibilidade |
| Linha de credencial / rodapé | Montserrat | 300 | CAIXA ALTA, letter-spacing ~0.2em, tamanho pequeno |

Hierarquia usada no cabeçalho: símbolo → "Dra. Andressa Namba" (Cormorant) → "CIRURGIÃ-DENTISTA · CRO-SP 158296" (Montserrat espaçada) → filete fino `--linha`.

## Documentos de impressão (`documentos-impressao/`)

| Arquivo | Formato | Campos a preencher |
|---|---|---|
| A4/Receituario-Andressa-Namba.pdf | A4 | Paciente, área livre, Data, Assinatura |
| A4/Fundo-Receituario-300dpi.png | A4, 300 dpi | Só fundo (cabeçalho, rodapé, marca d'água), para papel timbrado |
| A4/Pedido-Escaneamento-Intraoral.pdf | A4 | Paciente, Observações, Local/data, Assinatura |
| A4/Pedido-Documentacao-Ortodontica-Escaneamento.pdf | A4, 2 págs | Paciente, checklist (5 fotos intraorais, 3 extraorais, panorâmica, telerradiografia c/ traçados, escaneamento, outros), Local/data, Assinatura. A pág. 2 traz as orientações de escaneamento (cita Sousmile) |
| A5/Receituario-A5.pdf | A5 (talão) | Paciente, área livre, Data, Assinatura |
| A5/Receituario-A5-2-por-folha-A4.pdf | 2×A5 em A4 paisagem | idem, com marcas de corte |
| A5/Atestado-A5.pdf | A5 (talão) | Sr.(a), documento, das __ às __ do dia __/__/__, dias de convalescença, CID (só com autorização do paciente), local/data, assinatura |
| A5/Atestado-2-por-folha-A4.pdf | 2×A5 em A4 paisagem | idem |

Texto padrão do atestado: "Atesto, para os devidos fins, que o(a) Sr.(a) ___ portador(a) do documento ___ esteve sob meus cuidados profissionais no período das ___ às ___ do dia ___/___/___, necessitando o(a) mesmo(a) de ___ dia(s) de convalescença. CID ___."

Para o app gerar esses documentos já preenchidos, use os PDFs como referência visual e/ou o `codigo-gerador/`.

## Código gerador (`codigo-gerador/`)

Scripts Python com ReportLab que geram todos os PDFs em vetor. Base comum em `build.py`: desenho do símbolo a partir do SVG, cabeçalho, rodapé e marca d'água.

- `build.py`: receituário A4 e funções base (`simbolo`, `spaced`, `pagina`)
- `templates.py`: pedidos de escaneamento
- `atestado.py`: atestado A5 e 2-por-folha
- `receituario_a5.py`: receituário A5 e 2-por-folha

Para rodar em outro ambiente, ajuste os caminhos fixos: `F = "/home/claude/fonts/"` (fontes), o caminho do `simbolo-AN.svg` e os de saída. Os scripts esperam pesos estáticos (`Cormorant-Medium.ttf`, `Cormorant-Italic.ttf`, `Montserrat-Light.ttf`, `Montserrat-Regular.ttf`), que podem ser baixados do Google Fonts ou gerados das fontes variáveis com `fontTools.varLib.instancer`.
